import emoji
n=input("Input: ")
print(f"OutPut: {emoji.emojize(n,language='alias')}")
