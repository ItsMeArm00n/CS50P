n = input("")
print(n.lower())
