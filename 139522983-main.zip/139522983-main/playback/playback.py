n=input("")
print(n.replace(" ","..."))
