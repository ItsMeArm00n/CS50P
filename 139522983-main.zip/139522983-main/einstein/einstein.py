m=int(input("m: "))
print("E: ",m*300000000**2)
