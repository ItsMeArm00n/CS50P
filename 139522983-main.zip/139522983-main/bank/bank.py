n=input("Greating: ").strip().lower()
z="hello"
if n==z or z in n:
    print("$0")
elif n[0]=="h" or n[0]=="H":
    print("$20")
else:
    print("$100")
